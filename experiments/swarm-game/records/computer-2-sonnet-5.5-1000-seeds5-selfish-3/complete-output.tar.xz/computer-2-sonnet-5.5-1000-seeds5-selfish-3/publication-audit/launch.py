import json,os,pathlib,subprocess
root=pathlib.Path.cwd()
out=root/'results/computer-2-sonnet-5.5-1000-seeds5-selfish-3'
log=out/'parallel.log'
command=['/opt/homebrew/bin/uv','run','--frozen','--no-editable','python','-u','scripts/run_concurrent_matrix.py','--output',str(out),'--env-file',str(root.parent/'intentional-agent-luna-e75a825/.env'),'--workers','25']
with log.open('ab',buffering=0) as stream:
 p=subprocess.Popen(command,cwd=root,stdin=subprocess.DEVNULL,stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
keep_awake=subprocess.Popen(['/usr/bin/caffeinate','-i','-w',str(p.pid)],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,start_new_session=True)
receipt={'session_id':p.pid,'launcher_pid':p.pid,'caffeinate_pid':keep_awake.pid,'command':command,'log':str(log),'output':str(out)}
(out/'session.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
