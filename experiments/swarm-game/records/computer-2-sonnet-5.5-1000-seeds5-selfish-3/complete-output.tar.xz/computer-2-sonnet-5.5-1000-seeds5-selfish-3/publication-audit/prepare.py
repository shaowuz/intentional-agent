import json, pathlib, subprocess, sys
from dotenv import load_dotenv
from swarm_game.config import Config, MODELS
from swarm_game.matrix import preview, episode_plan, run_matrix
from swarm_game.game import initial_state
from swarm_game.storage import write_json, provenance
root=pathlib.Path.cwd()
audit=root/'launch-records/computer-2-sonnet-5.5-1000-seeds5'
out=root/'results/computer-2-sonnet-5.5-1000-seeds5-selfish-3'
raw=json.loads((root/'configs/computer-2-sonnet-5.5-1000-seeds5.json').read_text())
base=json.loads((root/'configs/experiment_matrix.json').read_text())
expected=json.loads(json.dumps(base)); expected.update(models=['anthropic/claude-sonnet-5.5'],selfish_counts=[3],seeds=list(range(5))); expected['game']['message_tokens']=1000
assert raw == expected
p=preview(raw); spec=p['spec']
assert (p['episodes'],p['encounters'],p['requests_before_retries'])==(25,1250,5250)
assert MODELS['anthropic/claude-sonnet-5.5']=='anthropic'
assert spec['game']['tokenizer']=='o200k_base' and spec['game']['max_completion_tokens']==4096
references={}
for entry in episode_plan(spec):
 c=Config(**entry['config']); state=initial_state(c)
 design={k:state[k] for k in ('players','roles','schedule')}
 assert design==references.setdefault(c.seed,design)
 assert c.message_tokens==1000 and c.provider=='anthropic'
write_json(audit/'preview.json',p)
load_dotenv(root.parent/'intentional-agent-luna-e75a825/.env',override=False)
class Prepared(Exception): pass
def stop_before_generations(_): raise Prepared()
try:
 run_matrix(raw,out,progress=stop_before_generations)
except Prepared:
 pass
else:
 raise RuntimeError('Expected pre-generation handoff')
assert not (out/'episodes').exists()
sha=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
receipt={'source_commit':sha,'model':spec['models'][0],'config':str(root/'configs/computer-2-sonnet-5.5-1000-seeds5.json'),'output':str(out),'python':sys.version,'provenance':provenance(),'preview':p,'matched_roles_and_schedules_verified':True,'initialization':'Unmodified run_matrix saved runtime and passed live capability check; stopped at first episode progress callback before any generation.','scheduler':'scripts/run_concurrent_matrix.py','workers':25,'source_changes':False}
write_json(out/'launch_provenance.json',receipt)
print(json.dumps({'source_commit':sha,'prepared':True,'catalog':json.loads((out/'catalog.json').read_text()),'output':str(out)},indent=2))
