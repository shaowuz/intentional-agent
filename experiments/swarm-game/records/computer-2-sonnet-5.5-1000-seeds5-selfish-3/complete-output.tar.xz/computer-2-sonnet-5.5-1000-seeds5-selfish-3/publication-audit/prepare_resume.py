import pathlib,shutil,json,datetime,hashlib,difflib
root=pathlib.Path.cwd(); out=root/'results/computer-2-sonnet-5.5-1000-seeds5-selfish-3'
audit=root/'launch-records/computer-2-sonnet-5.5-1000-seeds5/retry-extension-1'
audit.mkdir(exist_ok=False)
backup=audit/'original-output'; shutil.copytree(out,backup)
original=(root/'scripts/run_concurrent_matrix.py').read_text()
needle='    load_dotenv(args.env_file, override=False)'
replacement='''    # User-authorized retry-policy extension; frozen source and validation unchanged.
    from swarm_game import runner
    assert runner.collect_response.__kwdefaults__ == {"correction_attempts": 1}
    runner.collect_response.__kwdefaults__["correction_attempts"] = 5

'''+needle
assert original.count(needle)==1
modified=original.replace(needle,replacement)
modified=modified.replace("'validation_override': override, 'recovery': recovery,", "'validation_override': override, 'recovery': recovery,\n            'retry_policy_override': {'original_correction_attempts': 1, 'correction_attempts': 5, 'max_total_attempts': 6, 'authorization': 'User explicitly authorized increased corrections with unchanged validation and preserved original responses'},")
script=audit/'resume_concurrent.py'; script.write_text(modified)
(audit/'scheduler.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),modified.splitlines(True),fromfile='original/scripts/run_concurrent_matrix.py',tofile='retry-extension-1/resume_concurrent.py')))
hashes={str(p.relative_to(backup)):hashlib.sha256(p.read_bytes()).hexdigest() for p in backup.rglob('*') if p.is_file()}
(audit/'original_sha256.json').write_text(json.dumps(hashes,indent=2)+'\n')
receipt={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'authorization':'Increase correction attempts; preserve all original responses and modification records; resume unfinished episodes in parallel; unchanged validation; no replay of completed work.','original_max_total_attempts':2,'new_max_total_attempts':6,'frozen_runtime_modified':False,'backup':str(backup),'scheduler':str(script),'scheduler_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'original_files':len(hashes)}
(audit/'authorization.json').write_text(json.dumps(receipt,indent=2)+'\n')
(out/'retry_policy_extension.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
