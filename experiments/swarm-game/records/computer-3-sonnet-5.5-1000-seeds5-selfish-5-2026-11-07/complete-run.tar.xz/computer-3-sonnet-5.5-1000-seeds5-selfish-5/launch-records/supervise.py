"""Supervise the authorized 25-episode Sonnet cohort with frozen inputs."""

from datetime import datetime, timezone
import hashlib
import os
from pathlib import Path
import resource
import subprocess
import sys

LAUNCH = Path(__file__).resolve().parent
WORKSPACE = LAUNCH.parents[1]
OUTPUT = WORKSPACE / 'results' / LAUNCH.name
sys.path.insert(0, str(OUTPUT / 'runtime'))

from swarm_game.export_contract import validate_output
from swarm_game.storage import exclusive_run, provenance, read_json, write_json


def now():
    return datetime.now(timezone.utc).isoformat()


with exclusive_run(LAUNCH, lock_name='supervisor.lock'):
    frozen = read_json(LAUNCH / 'provenance.json')
    assert provenance() == frozen['runtime_provenance']
    for filename, expected in frozen['files'].items():
        assert hashlib.sha256(Path(filename).read_bytes()).hexdigest() == expected, filename
    spec = read_json(OUTPUT / 'spec.json')
    assert spec['models'] == ['anthropic/claude-sonnet-5.5']
    assert spec['selfish_counts'] == [5] and spec['seeds'] == list(range(5))
    assert spec['game']['message_tokens'] == 1000
    assert spec['game']['max_completion_tokens'] == 4096
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    resource.setrlimit(resource.RLIMIT_NOFILE, (min(max(soft, 4096), hard), hard))
    command = [sys.executable, '-u', str(LAUNCH / 'run_concurrent_matrix.py'),
               '--output', str(OUTPUT), '--env-file', str(WORKSPACE / '.env'),
               '--workers', '25']
    child = subprocess.Popen(command, cwd=LAUNCH, stdin=subprocess.DEVNULL)
    awake = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-s', '-w', str(os.getpid())],
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                             stderr=subprocess.DEVNULL)
    receipt = {'status': 'running', 'started_at': now(), 'supervisor_pid': os.getpid(),
               'runner_pid': child.pid, 'session_id': os.getsid(0), 'caffeinate_pid': awake.pid,
               'command': command, 'output': str(OUTPUT), 'log': str(LAUNCH / 'run.log'),
               'source_commit': frozen['source_commit'], 'checkout': frozen['checkout'],
               'runtime_provenance': frozen['runtime_provenance'],
               'model': spec['models'][0], 'message_tokens': 1000, 'seeds': spec['seeds'],
               'concurrent_episodes': 25, 'requests_per_episode': 1,
               'maximum_concurrent_requests': 25,
               'supervisor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    write_json(LAUNCH / 'launch.json', receipt)
    print(f'Runner {child.pid}: 25 concurrent Sonnet episodes, one request per episode', flush=True)
    code = child.wait()
    execution = read_json(OUTPUT / 'execution.json') if (OUTPUT / 'execution.json').exists() else {}
    complete = code == 0 and execution.get('status') == 'complete' and execution.get('completed_episodes') == 25
    result = {**receipt, 'status': 'complete' if complete else execution.get('status', 'failed'),
              'exit_code': code, 'finished_at': now(),
              'completed_episodes': execution.get('completed_episodes', 0)}
    if complete:
        try:
            result['validation'] = validate_output(OUTPUT)
        except Exception as exc:
            result.update(status='validation_failed', error=str(exc))
            code = 1
    write_json(LAUNCH / 'completion.json', result)
    print(f'Runner exit {code}; status {result["status"]}', flush=True)
    raise SystemExit(code)
