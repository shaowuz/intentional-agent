from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import signal
import subprocess
import time

root = Path('/Users/rworzger/Library/Mobile Documents/com~apple~CloudDocs/AI_Swarm_Hackathon')
launch = root/'launches/computer-3-luna-selfish-5'
output = root/'results/computer-3-luna-selfish-5'
pid = 48298
paused = False

def command():
    return subprocess.run(['ps','-p',str(pid),'-o','command='],capture_output=True,text=True).stdout.strip()

def records():
    return [(p,json.loads(p.read_text())) for p in output.glob('episodes/*/requests/*.json')]

try:
    deadline = time.monotonic() + 180
    while time.monotonic() < deadline:
        argv = command()
        if not argv:
            raise SystemExit('Serial process exited before handoff; inspect completion before continuing')
        assert '/intentional-experiments' in argv and 'computer-3-luna-selfish-5' in argv
        pending = [p for p,r in records() if r.get('status') == 'requesting']
        if pending:
            p = pending[-1]
            while time.monotonic() < deadline and json.loads(p.read_text()).get('status') == 'requesting':
                time.sleep(0.01)
        os.kill(pid, signal.SIGSTOP)
        paused = True
        state = subprocess.check_output(['ps','-p',str(pid),'-o','stat='],text=True).strip()
        if 'T' not in state:
            os.kill(pid,signal.SIGCONT); paused=False
            continue
        saved = records()
        if any(r.get('status') == 'requesting' for _,r in saved):
            os.kill(pid,signal.SIGCONT); paused=False
            continue
        accepted = {str(p.relative_to(output)):hashlib.sha256(p.read_bytes()).hexdigest()
                    for p,r in saved if r.get('complete')}
        receipt = {'at':datetime.now(timezone.utc).isoformat(), 'reason':'User requested concurrent independent episodes',
                   'serial_python_pid':pid, 'in_flight_requests_at_stop':0,
                   'accepted_requests':len(accepted), 'accepted_request_sha256':accepted,
                   'matrix_manifest_sha256':hashlib.sha256((output/'matrix_manifest.json').read_bytes()).hexdigest()}
        (launch/'concurrency-handoff.json').write_text(json.dumps(receipt,indent=2)+'\n')
        # SIGTERM stays pending while stopped; SIGCONT delivers it before further work.
        os.kill(pid,signal.SIGTERM)
        os.kill(pid,signal.SIGCONT)
        paused=False
        print('Stopped serial runner between requests; preserved',len(accepted),'accepted responses.',flush=True)
        break
    else:
        raise SystemExit('No safe request boundary found; serial runner remains active')
finally:
    if paused:
        os.kill(pid,signal.SIGCONT)
