import datetime
import fcntl
import json
import os
from pathlib import Path
import subprocess

from swarm_game.export_contract import validate_output
from swarm_game.matrix import normalize_spec
from swarm_game.storage import provenance, write_json

LAUNCH = Path(__file__).resolve().parent
WORKSPACE = LAUNCH.parents[1]
REPO = Path('/var/folders/_f/t5xz6l5n0lv90kpdtq7wc9jr0000gn/T/intentional-agent-publish-wz9dkofw/repository')
OUTPUT = WORKSPACE / 'results/computer-3-luna-selfish-5'
COMMIT = 'e75a825d12fb8b0e77f45f1e486fb02483455ea5'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


with (LAUNCH / 'supervisor.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == COMMIT
    subprocess.run(['git', 'diff', '--quiet', 'HEAD'], cwd=REPO, check=True)
    assert provenance() == json.loads((LAUNCH / 'provenance.json').read_text())
    config = json.loads((REPO / 'configs/computer-3-luna.json').read_text())
    assert config == json.loads((LAUNCH / 'config.json').read_text())
    command = ['/opt/homebrew/bin/uv', 'run', '--frozen', '--no-editable',
               'intentional-experiments', '--env-file', str(WORKSPACE / '.env'), 'matrix',
               '--config', 'configs/computer-3-luna.json', '--output', str(OUTPUT), '--execute']
    if OUTPUT.exists():
        assert json.loads((OUTPUT / 'spec.json').read_text()) == normalize_spec(config)
        assert json.loads((OUTPUT / 'matrix_manifest.json').read_text())['provenance'] == provenance()
        command[command.index('--config') + 1] = str(OUTPUT / 'spec.json')
        command.append('--resume')
    env = dict(os.environ, UV_CACHE_DIR='/private/tmp/intentional-agent-uv-cache',
               UV_PROJECT_ENVIRONMENT=str(LAUNCH / '.venv'), PYTHONUNBUFFERED='1', UV_NO_PROGRESS='1')
    env.pop('PYTHONPATH', None)
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    started = now()
    child = subprocess.Popen(command, cwd=REPO, env=env, stdin=subprocess.DEVNULL)
    awake = subprocess.Popen(['/usr/bin/caffeinate', '-i', '-s', '-w', str(os.getpid())],
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    receipt = {'status': 'running', 'started_at': started, 'source_commit': COMMIT,
               'supervisor_pid': os.getpid(), 'session_id': os.getsid(0), 'runner_pid': child.pid,
               'caffeinate_pid': awake.pid, 'command': command, 'cwd': str(REPO),
               'log': str(LAUNCH / 'run.log'), 'output': str(OUTPUT),
               'source_archive': str(LAUNCH / 'source-e75a825.tar.gz')}
    write_json(LAUNCH / 'launch.json', receipt)
    print(f"Launched runner {child.pid} at {started}", flush=True)
    code = child.wait()
    result = {**receipt, 'status': 'failed' if code else 'complete',
              'exit_code': code, 'finished_at': now()}
    if code == 0:
        try:
            result['validation'] = validate_output(OUTPUT)
        except Exception as exc:
            result.update(status='validation_failed', error=str(exc))
            code = 1
    write_json(LAUNCH / 'completion.json', result)
    print(f"Runner exit {code}; status {result['status']}", flush=True)
    raise SystemExit(code)
